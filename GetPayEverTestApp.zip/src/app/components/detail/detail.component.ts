import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { UserService } from '../../services/index';
import { MatSnackBar } from '@angular/material';

@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.scss']
})
export class DetailComponent implements OnInit {
  loading = false;
  userDetail: any;
  currentUserId: any;

  constructor(private route: ActivatedRoute, private router: Router, private userService: UserService, private snackBar: MatSnackBar) { }

  ngOnInit() {
    this.currentUserId = Number(this.route.snapshot.params.userId);

    this.userService.getUserDetails(this.currentUserId).subscribe(
      result => {
        const response = result.json();
        console.log(response);
        this.userDetail = response.data;
      },
      error => {
        this.snackBar.open(`Error occurred. ${error}`, '', {
          duration: 2000
        });
        this.loading = false;
      },
      () => this.loading = false
    );
  }

  goback(): void {
    this.router.navigate([`home`]);
  }

}
