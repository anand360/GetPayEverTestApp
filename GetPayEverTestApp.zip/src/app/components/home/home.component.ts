import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { UserService } from '../../services/index';
import { Observable } from 'rxjs';
import { MatSnackBar } from '@angular/material';

@Component({
    selector: 'app-home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
    userloading = false;
    users: any;
    totalUsers: number;
    pageIndex = 1;
    pageLength = 3;
    pageLengthOption = [3];

    constructor(private router: Router, private userService: UserService, public snackBar: MatSnackBar) { }

    ngOnInit(): void {
        this.userloading = true;
        this.userService.getAll(this.pageIndex).subscribe(
            result => {
                const response = result.json();
                console.log(response);
                this.users = response.data;
                this.totalUsers = response.total;
            },
            error => {
                this.snackBar.open(`Error occurred. ${error}`, '', {
                    duration: 2000
                });
                this.userloading = false;
            },
            () => this.userloading = false
        );
    }

    getUser(pageno: number): void {
        this.userService.getAll(pageno).subscribe(
            result => {
                const response = result.json();
                console.log(response);
                this.users = response.data;
                this.totalUsers = response.total;
            },
            error => {
                this.snackBar.open(`Error occurred. ${error}`, '', {
                    duration: 2000
                });
                this.userloading = false;
            },
            () => this.userloading = false
        );
    }

    navUserDetail(userId: number): void {
        this.router.navigate([`user/${userId}`]);
    }

    onPageChange(e): void {
        const pageEvent = e;
        this.getUser(pageEvent.pageIndex + 1);
    }
}
