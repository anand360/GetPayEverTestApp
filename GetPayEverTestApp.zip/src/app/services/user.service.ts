import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';

@Injectable()
export class UserService {
    headers: Headers;
    options: RequestOptions;

    constructor(private http: Http) {
        this.headers = new Headers({ 'Content-Type': 'application/json' });
        this.options = new RequestOptions({ headers: this.headers });
    }

    getAll(pageno: number): Observable<Response> {
        return this.http.get('https://reqres.in/api/users?page=' + pageno, this.options);
    }

    getUserDetails(userId: number): Observable<Response> {
        return this.http.get('https://reqres.in/api/users/' + userId, this.options);
    }
}
